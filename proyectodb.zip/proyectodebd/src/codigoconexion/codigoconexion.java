/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codigoconexion;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

/**
 *
 * @author KELVER
 */
public class codigoconexion {
    Connection conectar=null;
    public Connection conexion(){
        
        try {
          Class.forName("com.mysql.jdbc.Driver");
          conectar=(Connection) DriverManager.getConnection("jdbc:mysql://localhost/basedpro","root","");
          
          JOptionPane.showMessageDialog(null,"Conexion exitosa :3");
          
        } catch (Exception e) { 
            JOptionPane.showMessageDialog(null,"Error al conectar "+ e.getMessage());
            
        }
        
        
        return conectar;
    }
    
        
}
